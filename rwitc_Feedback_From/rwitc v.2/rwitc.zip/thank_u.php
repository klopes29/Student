<!--<?php
//echo "<pre>";
//print_r($_GET);
//if(isset($_GET['last_id'])){
//	$action="tst.php?last_id=".$_GET['last_id'];
//} else{
//	$action="tst.php";
//}
?>-->

<!DOCTYPE html>
<html>

<head> <title>Home - RWITC</title>

 <link rel="stylesheet" type="text/css" href="main.css">
</head>

<body>

<article>
  <header align="center">
  	<img src="logo.jpeg" alt="logo" />
    <h1>ROYAL WESTERN INDIA TURF CLUB, LTD.</h1>
    <p>Race Course, Mahalakshmi, Mumbai – 400034.</p>
    <p>E-mail : secretary@rwitc.com, Website – <a href="http://www.rwitc.com">www.rwitc.com</a></p>
  </header>
 
</article>
<br><br>
<br>
<br>
<br>


<p class="p" align="center" style="color: red;font-size: 50px;"><i><b>Thank You For Your Valuable Feedback !!! </i> </p>
<br/>


<br>

</html>